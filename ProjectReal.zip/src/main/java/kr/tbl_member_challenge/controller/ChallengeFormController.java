package kr.tbl_member_challenge.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.board.controller.Controller;
import kr.dao.ChallDAO;
import kr.entity.sumMonthPay;
import kr.entity.tbl_member_challenge;

public class ChallengeFormController implements Controller {

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String mb_id = request.getParameter("mb_id");
		 
		
		return "mychall";
	
	}
}

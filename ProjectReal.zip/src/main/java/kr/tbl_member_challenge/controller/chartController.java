package kr.tbl_member_challenge.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import kr.board.controller.Controller;
import kr.dao.ChallDAO;
import kr.entity.sumMonthPay;
import kr.entity.tbl_member;

public class chartController implements Controller {

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		tbl_member mvo = (tbl_member)session.getAttribute("mvo");
		ChallDAO dao = new ChallDAO();
		List<sumMonthPay> paylist = dao.sumMonPay(mvo.getMb_id());
		
		int[] sumPay = new int[12];
		for(sumMonthPay p:paylist) {
			for(int j=1;j<=12;j++) {
				if(p.getDay().equals("20220"+j)) {
					sumPay[j-1] = p.getSumPay();
				}
			}
		}
		Gson gson=new Gson();
		String json=gson.toJson(list);
		response.setContentType("text/json;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println(json);
		
		
		  return null;
	}
	
	

}
